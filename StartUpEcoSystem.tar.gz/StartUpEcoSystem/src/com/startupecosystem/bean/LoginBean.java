package com.startupecosystem.bean;

public class LoginBean {
	private String id;
	private String password;
	private String roleopt;
	public String getRoleopt() {
		return roleopt;
	}
	public void setRoleopt(String roleopt) {
		this.roleopt = roleopt;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
